#include "ebuildtest.hh"
 
int main(int argc, char *argv[]){
 
	HelloWorld helloworld;
	helloworld.run();
 
	return 0;
}
